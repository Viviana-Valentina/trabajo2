﻿using System;

namespace Application
{
    public class Class1
    {
    }
}
